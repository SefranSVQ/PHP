<?php 

    function generarAleatorio($numMin, $numMax){
        $valor = rand($numMin, $numMax);
        return $valor;
    }
?>