<?php


print "<p>Ejercicio incompleto</p>";


?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Obtener productos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Obtener productos</h1>

  <!--  ESCRIBA AQUI EL CÓDIGO HTML Y/O PHP NECESARIO -->


</body>
</html>